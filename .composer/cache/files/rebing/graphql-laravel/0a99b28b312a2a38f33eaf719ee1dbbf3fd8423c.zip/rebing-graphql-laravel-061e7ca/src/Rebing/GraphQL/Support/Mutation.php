<?php

namespace Rebing\GraphQL\Support;

class Mutation extends Field {

}
