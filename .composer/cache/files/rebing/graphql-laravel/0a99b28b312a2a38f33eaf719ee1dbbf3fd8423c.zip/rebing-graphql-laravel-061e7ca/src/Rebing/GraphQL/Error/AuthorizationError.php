<?php

namespace Rebing\GraphQL\Error;

use GraphQL\Error\Error;

class AuthorizationError extends Error {

}