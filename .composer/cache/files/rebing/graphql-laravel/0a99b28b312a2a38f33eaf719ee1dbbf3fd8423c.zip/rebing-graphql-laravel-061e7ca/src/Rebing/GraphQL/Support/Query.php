<?php

namespace Rebing\GraphQL\Support;

class Query extends Field {

}
