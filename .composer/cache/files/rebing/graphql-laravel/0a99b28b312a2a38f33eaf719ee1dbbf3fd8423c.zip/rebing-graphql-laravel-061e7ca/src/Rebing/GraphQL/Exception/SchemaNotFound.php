<?php

namespace Rebing\GraphQL\Exception;

class SchemaNotFound extends \Exception {

}