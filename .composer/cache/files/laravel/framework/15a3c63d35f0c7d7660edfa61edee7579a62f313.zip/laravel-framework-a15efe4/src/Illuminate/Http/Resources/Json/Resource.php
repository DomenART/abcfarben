<?php

namespace Illuminate\Http\Resources\Json;

class Resource extends JsonResource
{
    //
}
