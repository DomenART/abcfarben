<?php namespace Folklore\GraphQL\Exception;

use Exception;

class SchemaNotFound extends Exception
{
}
