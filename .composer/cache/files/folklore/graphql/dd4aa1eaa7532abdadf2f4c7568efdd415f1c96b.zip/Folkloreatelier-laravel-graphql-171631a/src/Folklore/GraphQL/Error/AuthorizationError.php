<?php namespace Folklore\GraphQL\Error;

use GraphQL\Error\Error;

class AuthorizationError extends Error
{

}
