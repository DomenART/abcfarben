<?php namespace Folklore\GraphQL\Exception;

use Exception;

class TypeNotFound extends Exception
{
}
