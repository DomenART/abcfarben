<?php

namespace Folklore\GraphQL\Support;

class Query extends Field
{
    
}
