<?php

return [
    [
        'test' => 'Example 1'
    ],
    [
        'test' => 'Example 2'
    ],
    [
        'test' => 'Example 3'
    ]
];
